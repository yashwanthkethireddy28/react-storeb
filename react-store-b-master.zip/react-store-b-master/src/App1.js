import React from "react"

export default function App1() {
    return(
        <div style={{backgroundColor: 'yellow'}}>App1</div>
    )
}