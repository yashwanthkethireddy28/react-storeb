import React from "react"

export default function App2() {
    return(
        <div style={{backgroundColor: 'yellow'}}>App2</div>
    )
}